# Implementation of Cosine Similarity function for large data matrices. 
